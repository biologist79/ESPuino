# Kicad Library

This is my unorganized library of KiCAD Symbols and Footprints.

This repo is neither complete nor correct. But I was asked to share my footprints either way.

Have fun, 
Paul